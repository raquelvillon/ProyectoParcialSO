..\SuscribeRSS\dist
En ese directorio esta el archivo jar para ejecutar directamente el programa. 
